class Calculadora{
  //1. Base 10 a 2/////////////////////////////////////////////////////////////////////
  base10_2() {
      let $input = document.getElementById("result");
      let numero = parseInt($input.value);
      let resultado = "";
      while (numero > 0) {
        resultado = (numero % 2) + resultado;
        numero = Math.floor(numero / 2);
      }
      $input.value = `[Base10=${$input.value}] ==> Base2=${resultado}`;
    }
    
    //2-Base 10 a 16/////////////////////////////////////////////////////////////////////
    base10_16() {
        let $input = document.getElementById("result");
        let numero = parseInt($input.value);
        let arreglo = this.isDigitos(numero, 10);
        let resultado = "";
        let base16;
        while (arreglo.length > 0) {
          base16 = 0;
          for (let i = 0; i < 4 && arreglo.length > 0; i++) {
            base16 = base16 * 10 + arreglo.pop();
          }
          resultado = this.getHexadecimal(base16) + resultado;
        }
        $input.value = `[Base10=${numero}] ==> Base16=${resultado}`;
      }
      
      getHexadecimal(numero) {
        const letras = "ABCDEF";
        let resto;
        let resultado = "";
        while (numero > 0) {
          resto = numero % 16;
          if (resto >= 10) {
            resultado = letras.charAt(resto - 10) + resultado;
          } else {
            resultado = resto + resultado;
          }
          numero = Math.floor(numero / 16);
        }
        return resultado;
      }
      
      isDigitos(numero, base) {
        const digitos = [];
        while (numero > 0) {
          digitos.push(numero % base);
          numero = Math.floor(numero / base);
        }
        return digitos;
      }
     //3-Base 10 a 8 (hecho)/////////////////////////////////////////////////////////////////////
  base10_8() {
    let $input = document.getElementById("result");
    let numero = parseInt($input.value);
    let resultado = "";
    while (numero > 0) {
      resultado = (numero % 8) + resultado;
      numero = Math.floor(numero / 8);
    }
    $input.value = `[Base10=${$input.value}] ==> Base8=${resultado}`;
  }
  
   separarEnGrupos(numero, tamano) {
    const grupos = [];
    let grupo;
    while (numero > 0) {
      grupo = numero % Math.pow(10, tamano);
      numero = Math.floor(numero / Math.pow(10, tamano));
      grupos.unshift(grupo);
    }
    return grupos;
  }
    //4-Base 2 a 10 (si sale)/////////////////////////////////////////////////////////////////////
    base2_10(){
            let $input = document.getElementById("result");
            let numero = parseInt($input.value);
            let arreglo = this.isDigitos(numero, 10);
            let base10 = 0;
            for (let i = 0; i < arreglo.length; i++) {
              base10 += arreglo[i] * Math.pow(2, arreglo.length - 1 - i);
            }
            $input.value = `[Base2=${numero}] ==> Base10=${base10}`;
          }   
  //5-Base 2 a 16 (si sale)/////////////////////////////////////////////////////////////////////
  base2_16() {
    let $input = document.getElementById("result");
    let numero = $input.value;
    let arreglo = this.separarEnGrupos(numero, 4);
    let resultado = "";
    for (let i = 0; i < arreglo.length; i++) {
      resultado += this.getHexadecimal(parseInt(arreglo[i], 2));
    }
    $input.value = `[Base2=${numero}] ==> Base16=${resultado}`;
  }
  
 separarEnGrupos(numero, tamano) {
    const grupos = [];
    let grupo;
    while (numero.length > 0) {
      grupo = numero.slice(-tamano);
      numero = numero.slice(0, -tamano);
      grupos.unshift(grupo);
    }
    return grupos;
  }
  
  getHexadecimal(numero) {
    const letras = "ABCDEF";
    let resto;
    let resultado = "";
    while (numero > 0) {
      resto = numero % 16;
      if (resto >= 10) {
        resultado = letras.charAt(resto - 10) + resultado;
      } else {
        resultado = resto + resultado;
      }
      numero = Math.floor(numero / 16);
    }
    return resultado;
  }
//6-Base 2 a 8/////////////////////////////////////////////////////////////////////
Base2_8() {
    let input = document.getElementById("result");
    let numero = parseInt(input.value, 2);
    let octal = numero.toString(8);
    input.value = `[Base2=${numero}] ==> Base8=${octal}`;
  }
//7-Base N a Base N/////////////////////////////////////////////////////////////////////
BaseNaBasen() {
  let $input = document.getElementById("result");
  let num = $input.value;
  if(isNaN(num)){
  $input.value=("Error, ingrese un valor numerico")
  }else{
  let baseOrigen = prompt("Ingresa la base del número ingresado:");
  let baseDestino = prompt("Ingresa la base a la que quieres convertir el número:")
  if(baseOrigen==10 && baseDestino==2){
      result= this.base10_2(num)
      $input.value=result
  }else if(baseOrigen==10 && baseDestino==16){
      result= this.base10_16(num)
      $input.value=result
  }else if(baseOrigen==10 && baseDestino==8){
      result= this.base10_8(num)
      $input.value=result
  }else if(baseOrigen==2 && baseDestino==10){
      result= this.base2_10(num)
      $input.value=result
  }else if(baseOrigen==2 && baseDestino==16){
      result= this.base2_16(num)
      $input.value=result
  }else if(baseOrigen==2 && baseDestino==8){
      result= this.Base2_8(num)
      $input.value=result
  }
}
}
//8-Dar vuelto/////////////////////////////////////////////////////////////////////
calcular_Vuelto() {
  let vuelto = parseInt(prompt("Ingresa el valor del vuelto:"));

  if (isNaN(vuelto)) {
    alert("El valor ingresado no es válido.");
    return;
  }

  const billetes = [50, 20, 10, 5, 1];
  let respuesta = "";

  for (let i = 0; i < billetes.length; i++) {
    let cantidad = Math.floor(vuelto / billetes[i]);

    if (cantidad > 0) {
      respuesta += `${cantidad} billete(s) de $${billetes[i]} `;
      vuelto -= cantidad * billetes[i];
    }
  }

  alert(respuesta);
}
//9.Romanos/////////////////////////////////////////////////////////////////////
sacarromanos(numero) {
  let unidades = ["", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"];
  let decenas = ["", "X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC", "C"];

  let decena = Math.floor(numero / 10);
  let unidad = numero % 10;

  return decenas[decena] + unidades[unidad];
}

darRomanos() {
  let $input = document.getElementById("result");
  let numero = parseInt($input.value);
  if (numero < 1 || numero > 100) {
      $input.value = `Por favor ingresar un número entre 1 y 100`;
  } else {
      let resul = this.sacarromanos(numero);
      $input.value = `[${numero}] a romano es ==> ${resul}`;
  }
}
  
//10-Buscar Cadena/////////////////////////////////////////////////////////////////////
buscar_cadena(){ 
let cadena = prompt("Ingresa la cadena:");
let subcadena = prompt("Ingresa la subcadena a buscar:");
let posicion = cadena.indexOf(subcadena);
if (posicion !== -1) {
  alert(`La subcadena "${subcadena}" se encontró en la posición ${posicion} de la cadena "${cadena}"`);
} else {
  alert(`La subcadena "${subcadena}" no se encontró en la cadena "${cadena}"`);
}
}
//11-Mayor Elemento Arreglo/////////////////////////////////////////////////////////////////////
isMayor(arreglo) {
  let mayor = arreglo[0];
  for (let i = 1; i < arreglo.length; i++) {
    if (arreglo[i] > mayor) {
      mayor = arreglo[i];
    }
  }
  return mayor;
}
MayorArreglo(){
  let $input=document.getElementById("result")
  let numero = $input.value.split(",");
  let mayor =this.isMayor(numero)
  $input.value=`El numero mayor del arreglo [${numero}] es: [${mayor}]`
}
//12-Menor Elemento Arreglo/////////////////////////////////////////////////////////////////////
MenorArreglo(){
  let $input=document.getElementById("result")
  let numero = $input.value.split(",");
  let mayor =this.isMayor(numero)
  let menor = numero[0]
  for (let i = 1; i < numero.length; i++) {
      if (numero[i] < menor) {
        menor = numero[i];
      }
    }
  
  $input.value=`El numero menor del arreglo [${numero}] es: [${menor}]`
}
 //13-Buscar Arreglo/////////////////////////////////////////////////////////////////////
 buscararreglo(arreglo, buscado) {
  let pos = 0, c = 0
  while (c < arreglo.length && pos === 0) {
      if (arreglo[c] === buscado) {
          pos = c
      }
      c += + 1
  }
  return pos
}
  buscar() {
  let $input = document.getElementById("result")
  let num = $input.value.trim()
  let rege = /[^0-9,]/g;  // Busca cualquier carácter que no sea un número o una coma
  num = num.replace(rege, '');   // Elimina calquier carácter que no sea un número o una coma
  if (!num) {
      $input.value = `No se ingreso ningún arreglo`
  } else {
      let arreglo = num.split(",")
      let buscar = prompt("¿Qué numero deseas buscar?")
      let resultado = this.buscararreglo(arreglo, buscar)
      $input.value = (`De la siguiente serie '${arreglo}' el número ${buscar} se encuentran en la posición: ${resultado}.`);
  }
}
//14-Eliminar Elemento Arreglo
isBuscado(arr,buscar){
  let pos=0,enc=0
  //[2,4,6]  4
  while(pos<arr.length && enc==0){
      if (arr[pos]==buscar){
         enc=1
      }else{
          pos+=1
      }
  }
  if (enc == 1){
      return pos
  }else{
      return -1
  }
}

EliminarArreglo(){
  let $input= document.getElementById("result")
  let arreglo = $input.value.split(',').map(Number)  // Convertimos la cadena de entrada a un arreglo de números
  let buscado = parseInt(prompt("Ingrese el elemento que desea eliminar:")) 
  let indice = this.isBuscado(arreglo, buscado) // Obtenemos el índice del elemento que se desea eliminar
  if (indice !== -1) {
    arreglo.splice(indice, 1) // Eliminamos el elemento del arreglo
    alert `El elemento ha sido eliminado del arreglo.`
  } else {
    alert `El elemento no se encuentra en el arreglo.`
  }
  $input.value = `[${arreglo.toString()}]` // Mostramos el arreglo actualizado en el input
}
//15-Insertar elemento Arreglo
AgregarArreglo(){
let $input= document.getElementById("result")
let arreglo = $input.value.split(',').map(Number)  // Convertimos la cadena de entrada a un arreglo de números
let agregar = parseInt(prompt("Ingrese el elemento que desea agregar:")) 
let indice = this.isBuscado(arreglo, agregar) // Buscamos el índice del elemento que se desea agregar
if (indice !== -1) {
  alert(`El elemento ${agregar} ya se encuentra en el arreglo.`)
} else {
  arreglo.push(agregar) // Agregamos el elemento al arreglo
  alert(`El elemento ${agregar} ha sido agregado al arreglo.`)
  $input.value = `[${arreglo.toString()}]` // Mostramos el arreglo actualizado en el input
}
} 
//16 Cadena a Arreglo
cadenaAArreglo(cadena, separador) {
let arreglo = cadena.split(separador);
for (let i = 0; i < arreglo.length; i++) {
  arreglo[i] = Number(arreglo[i]);
}
return arreglo;
}

convertirYMostrar() {
let cadena = prompt("Ingrese una cadena separada por un caracter:");
let separador = prompt("Ingrese el caracter separador:");
let resultado = this.cadenaAArreglo(cadena, separador);

alert(`El arreglo generado es: [${resultado}]`);
document.getElementById("result").value = `[${resultado}]`;
}
//17-Arreglo a cadena
arregloACadena(arreglo, caracter) {
  let cadena = '';

  for (let i = 0; i < arreglo.length; i++) {
    cadena += arreglo[i];

    if (i !== arreglo.length - 1) {
      cadena += caracter;
    }
  }

  return cadena;
}

copiarArreglo() {
  let arreglo = prompt("Ingrese un arreglo separado por comas:");
  let caracter = prompt("Ingrese un caracter para separar el arreglo:");
  arreglo = arreglo.split(',');
  let resultado = this.arregloACadena(arreglo, caracter);
  alert(`El arreglo copiado a cadena es: ${resultado}`);
  document.getElementById("result").value = resultado;
}
//18.Palabra Oracion
convertirOracion(cadena) {
  let resultado = '';
  let primeraLetra = true;

  for (let i = 0; i < cadena.length; i++) {
    if (primeraLetra) {
      resultado += cadena[i].toUpperCase();
      primeraLetra = false;
    } else if (cadena[i] === ' ') {
      resultado += ' ';
      primeraLetra = true;
    } else {
      resultado += cadena[i].toLowerCase();
    }
  }

  return resultado;
}

convertirYMostrar2() {
  let cadena = window.prompt("Ingrese una cadena:");
  let resultado = this.convertirOracion(cadena);

  window.alert(`La cadena convertida es: ${resultado}`);
  document.getElementById("result").value = resultado;
}
 //19-Cantidad Caracteres especiales
 contarCaracteres(cadena) {
  let caracteres = {",": 0, ".": 0, ";": 0, ":": 0};

  for (let i = 0; i < cadena.length; i++) {
    if (cadena[i] in caracteres) {
      caracteres[cadena[i]]++;
    }
  }

  return caracteres;
}

contarYMostrar() {
  let cadena = prompt("Ingrese una cadena:");
  let resultado = this.contarCaracteres(cadena);

  let mensaje = "";
  for (let caracter in resultado) {
    mensaje += `hay ${resultado[caracter]} '${caracter}'\n`;
  }

  alert(mensaje);
}
//20 
sumarDigitos(cadena) {
  let suma = 0;
  for (let i = 0; i < cadena.length; i++) {
    suma += parseInt(cadena[i]);
  }
  return suma;
}

sumarYMostrar() {
  let cadena = prompt("Ingrese un número:");
  let resultado = this.sumarDigitos(cadena);

  let $input = document.getElementById("result");
  $input.value = `La suma de los dígitos es: ${resultado}`;
}
}
let cal = new Calculadora()

    


